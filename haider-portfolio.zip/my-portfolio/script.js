body{
  background-color: #f8f9fa;
  margin: 0;
  padding: 0;
}

.hero {
  background-color: #343a40;
  padding: 80px 20px;
}

.section-title {
  margin-top: 40px;
  margin-bottom: 20px;
}

.card {
  margin-bottom: 20px;
}

.footer {
  background-color: #343a40;
  padding: 10px 0;
  margin-top: 40px;
  }
